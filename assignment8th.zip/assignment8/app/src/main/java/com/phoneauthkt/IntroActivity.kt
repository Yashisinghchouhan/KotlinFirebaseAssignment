package com.phoneauthkt

import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_intro.*

class IntroActivity : AppCompatActivity() {
    private  lateinit var auth : FirebaseAuth
    //broadcast receiver
    lateinit var receiver : AirplanemodeChangeBroadcastReceiver
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)
          //broadcast receiver
        receiver = AirplanemodeChangeBroadcastReceiver()
        IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED).also {
            registerReceiver(receiver,it)
        }     //Login
        auth = FirebaseAuth.getInstance()

        Login.setOnClickListener {
            if(checking()){
                val email = Email.text.toString()
                val password = Password.text.toString()

                auth.signInWithEmailAndPassword(email,password)
                    .addOnCompleteListener(this){
                            task ->
                        if(task.isSuccessful){
                            var intent = Intent(this, LoggedIn::class.java)
                            intent.putExtra("email",email)
                            startActivity(intent)
                            //  Toast.makeText(this,"Login Suceessful", Toast.LENGTH_LONG).show()
                            finish()
                        }
                        else{
                            Toast.makeText(this,"Wrong Details", Toast.LENGTH_LONG).show()
                        }
                    }
            }
            else{
                Toast.makeText(this,"Enter the Details", Toast.LENGTH_LONG).show()
            }
        }
        //register button check
        Register.setOnClickListener {
            var intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
 }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(receiver)
    }
    private fun checking():Boolean{
        if(Email.text.toString().trim{it<=' '}.isNotEmpty()
            && Password.text.toString().trim{it<=' '}.isNotEmpty()
        ) {
            return true
        }
        return false
    }
}